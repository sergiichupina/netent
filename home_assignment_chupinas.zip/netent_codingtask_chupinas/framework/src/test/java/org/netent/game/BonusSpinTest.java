package org.netent.game;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assumptions.assumeTrue;

class BonusSpinTest {
    @Test
    @DisplayName("Assume a result around 100 (10% of 1000) bonuses")
    public void BonusWin10PercentageAssumption() {
        int wins = 0;
        Spin<Result> bonus = new BonusSpin();
        for (int i = 1; i <= 1000; i++) {
            Result result = bonus.spin();
            if (Result.BONUS.equals(result)) {
                wins++;
            }
        }
        assumeTrue(wins > 80 && wins < 120);
    }
}