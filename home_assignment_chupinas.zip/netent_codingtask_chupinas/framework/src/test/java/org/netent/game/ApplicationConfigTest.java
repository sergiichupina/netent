package org.netent.game;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.netent.game.ApplicationConfig.INSTANCE;

class ApplicationConfigTest {

    @Test
    @DisplayName("Return existing default property")
    void propertyExist() {
        Integer property = Integer.valueOf(INSTANCE.getProperty(Spin.BET_HIT_FREQUENCY_PROPERTY));
        assertEquals(0, property);
    }

    @Test
    @DisplayName("Throw exception if a key is invalid")
    void shouldThrowException() {
        Throwable exception = assertThrows(IllegalArgumentException.class, () -> {
            INSTANCE.getProperty("DUMMY_KEY");
        });
        assertEquals(exception.getMessage(), "Invalid key DUMMY_KEY");
    }

}