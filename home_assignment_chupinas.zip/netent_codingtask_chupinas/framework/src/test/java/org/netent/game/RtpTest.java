package org.netent.game;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class RtpTest {

    @Test
    @DisplayName("Return value")
    void calculate() {
        Rtp rtp = new Rtp(50, 100);
        assertEquals(50, rtp.calculate());
    }

    @Test
    @DisplayName("Return zero value")
    void throwException1() {
        Rtp rtp = new Rtp(0, 100);
        assertEquals(0, rtp.calculate());
    }

    @Test
    @DisplayName("Throw / by zero exception")
    void throwException() {
        Rtp rtp = new Rtp(100, 0);
        assertThrows(ArithmeticException.class, () -> {
            rtp.calculate();
        });
    }
}