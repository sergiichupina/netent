package org.netent.game;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assumptions.assumeTrue;

class BetSpinTest {

    @Test
    @DisplayName("Assume a result around 300 (30% of 1000) of wins")
    public void BonusWin10PercentageAssumption() {
        int wins = 0;
        Spin<Result> bet = new BetSpin();
        for (int i = 1; i <= 1000; i++) {
            Result result = bet.spin();
            if (Result.WIN.equals(result)) {
                wins++;
            }
        }
        final int result = wins;
        assumeTrue(wins > 270 && wins < 320, () -> " " + result);
    }
}