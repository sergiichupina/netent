package org.netent.game;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Rtp {

    private double totalWin;

    private double totalBet;

    public Rtp(double totalWin, double totalBet) {
        this.totalWin = totalWin;
        this.totalBet = totalBet;
    }

    public double calculate() {
        if(totalBet == 0){
            throw new ArithmeticException("/ by zero");
        }
        BigDecimal bigDecimal = new BigDecimal(100 * (totalWin / totalBet));
        return bigDecimal.setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    @Override
    public String toString() {
        return "Rtp: " + calculate() + "% (" + totalWin + "/" + totalBet + ")";
    }
}
