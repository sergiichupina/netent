package org.netent.game;

import static org.netent.game.ApplicationConfig.INSTANCE;

public class BetSpin implements Spin<Result> {

    private double hitFrequency;

    public BetSpin() {
        int hitFrequencyPercentage = Integer.valueOf(INSTANCE.getProperty(BET_HIT_FREQUENCY_PROPERTY));
        this.hitFrequency = (double) hitFrequencyPercentage / 100;
    }

    public Result spin() {
        return (Math.random() < this.hitFrequency) ? Result.WIN : Result.LOST;
    }
}
