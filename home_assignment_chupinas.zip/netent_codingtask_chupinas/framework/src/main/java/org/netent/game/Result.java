package org.netent.game;

public enum Result {
    WIN, BONUS, LOST;
}
