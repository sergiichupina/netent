package org.netent.game;

import java.io.IOException;
import java.util.Properties;
import java.util.logging.*;

public enum ApplicationConfig {
    INSTANCE;

    public static final String STATISTICS_AGRGUMENT = "-rtp";

    private final Properties properties;

    ApplicationConfig() {
        properties = new Properties();
        try {
            properties.load(getClass().getClassLoader().getResourceAsStream("application.properties"));
        } catch (IOException e) {
            getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage(), e);
        }
    }

    public String getProperty(String key) {
        String value = properties.getProperty(key);
        if (value == null) {
            throw new IllegalArgumentException("Invalid key " + key);
        }
        return value;
    }

    public Logger getLogger(String name) {
        Logger logger = Logger.getLogger(name);

        Formatter formatter = new Formatter() {
            @Override
            public String format(LogRecord record) {
                return record.getMessage() + "\n";
            }
        };
        ConsoleHandler consoleHandler = new ConsoleHandler();
        consoleHandler.setFormatter(formatter);
        logger.addHandler(consoleHandler);
        logger.setUseParentHandlers(false);
        return logger;
    }
}
