package org.netent.game;

public interface Spin<T> {

    String BONUS_HIT_FREQUENCY_PROPERTY = "bonus.hitFrequencyPercentage";

    String BET_HIT_FREQUENCY_PROPERTY = "bet.hitFrequencyPercentage";

    T spin();
}
