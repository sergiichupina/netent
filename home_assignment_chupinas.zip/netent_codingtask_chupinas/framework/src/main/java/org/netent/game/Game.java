package org.netent.game;

public interface Game<T, E> {

    E play(T input);

    double getTotalWin();

    double getTotalLoss();

}
