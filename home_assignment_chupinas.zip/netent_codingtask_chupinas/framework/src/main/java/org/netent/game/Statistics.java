package org.netent.game;

public interface Statistics {

    Rtp calculate(int trials);
}
