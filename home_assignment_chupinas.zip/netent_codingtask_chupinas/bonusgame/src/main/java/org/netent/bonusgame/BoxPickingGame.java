package org.netent.bonusgame;

import org.netent.game.Game;
import org.netent.game.Spin;

import static org.netent.game.ApplicationConfig.INSTANCE;

public class BoxPickingGame implements Game<Integer, Boolean> {

    private int reword;

    private Box[] boxes;

    private int totalWin;

    public BoxPickingGame(Spin boxSpin) {
        this.boxes = (Box[]) boxSpin.spin();
        this.reword = Integer.valueOf(INSTANCE.getProperty("boxpickinggame.reword"));
    }

    @Override
    public Boolean play(Integer boxNumber) {
        if (boxNumber > boxes.length || boxNumber <= 0) {
            return true;
        }

        Box box = boxes[boxNumber - 1];

        if (box.isOpened()) {
            return true;
        }

        if (box.isWin()) {
            totalWin += reword;
            box.setOpened(true);
            return true;
        }
        return false;
    }

    @Override
    public double getTotalWin() {
        return totalWin;
    }

    @Override
    public double getTotalLoss() {
        return 0;
    }
}
