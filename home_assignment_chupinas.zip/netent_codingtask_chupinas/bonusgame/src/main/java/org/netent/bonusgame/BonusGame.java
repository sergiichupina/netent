package org.netent.bonusgame;

import org.netent.game.Game;
import org.netent.game.Result;
import org.netent.game.Spin;

import static org.netent.game.ApplicationConfig.INSTANCE;

public class BonusGame implements Game<Integer, Boolean> {

    private int bets;

    private int stake;

    private Spin<Result> spin;

    private boolean playBoxGame;

    private int totalWin;

    private Game<Integer, Boolean> boxGame;

    public BonusGame(Spin spin) {
        this.stake = Integer.valueOf(INSTANCE.getProperty("bonusgame.stake"));
        this.spin = spin;
    }

    public Boolean play(Integer box) {
        bets++;

        if (!playBoxGame) {
            Result result = spin.spin();
            if (Result.BONUS.equals(result)) {
                boxGame = new BoxPickingGame(new BoxSpin());
                playBoxGame = true;
                return playBoxGame;
            }
            return false;
        }

        playBoxGame = boxGame.play(box);
        if (!playBoxGame) {
            totalWin += boxGame.getTotalWin();
        }

        return playBoxGame;
    }

    @Override
    public double getTotalWin() {
        return totalWin;
    }

    @Override
    public double getTotalLoss() {
        return bets * stake;
    }

    @Override
    public String toString() {
        return "Your result:" +
                " bets = " + bets +
                ", credits you lost = " + getTotalLoss() +
                ", credits you won = " + getTotalWin();
    }
}
