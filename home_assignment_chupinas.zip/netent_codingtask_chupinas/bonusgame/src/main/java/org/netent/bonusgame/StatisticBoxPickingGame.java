package org.netent.bonusgame;

import org.netent.game.Game;
import org.netent.game.Rtp;
import org.netent.game.Statistics;

import java.util.Random;
import java.util.logging.Logger;

import static org.netent.game.ApplicationConfig.INSTANCE;

public class StatisticBoxPickingGame implements Statistics {

    private static Logger LOGGER = INSTANCE.getLogger(StatisticBoxPickingGame.class.getName());

    private Game<Integer, Boolean> game;

    private int stake;

    public StatisticBoxPickingGame(Game game) {
        this.stake = Integer.valueOf(INSTANCE.getProperty("boxpickinggame.stake"));
        this.game = game;
    }

    public Rtp calculate(int trials) {
        long totalWins = 0;
        for (int i = 1; i <= trials; i++) {
            game = new BoxPickingGame(new BoxSpin());
            playGame(game);
            totalWins += game.getTotalWin();

        }
        Rtp rtp = new Rtp(totalWins, trials * stake);
        LOGGER.info(rtp.toString());
        return rtp;
    }

    private void playGame(Game<Integer, Boolean> game) {
        Random random = new Random();
        while (game.play(random.nextInt(5))) {
            continue;
        }
    }
}
