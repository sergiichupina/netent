package org.netent.bonusgame;

import org.netent.game.BonusSpin;
import org.netent.game.Game;
import org.netent.game.Statistics;

import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Logger;

import static org.netent.game.ApplicationConfig.INSTANCE;
import static org.netent.game.ApplicationConfig.STATISTICS_AGRGUMENT;

public class Runner {

    private static Logger LOGGER = INSTANCE.getLogger(Runner.class.getName());

    public static void main(String[] args) {

        Arrays.stream(args).forEach(s -> {
            if (STATISTICS_AGRGUMENT.equals(s)) {
                Game game = new BoxPickingGame(new BoxSpin());
                Statistics statistic = new StatisticBoxPickingGame(game);
                statistic.calculate(1000000);
                System.exit(0);
            }
        });

        Game<Integer, Boolean> bonusGame = new BonusGame(new BonusSpin());
        Boolean playBoxGame = false;
        try (Scanner scanner = new Scanner(System.in)) {
            LOGGER.info("Press 'y' to make a bet or press 'n' to quit");
            String readString = scanner.nextLine();
            while (true) {
                if ("n".equalsIgnoreCase(readString)) {
                    LOGGER.info(bonusGame.toString());
                    LOGGER.info("Thank you and good bye");
                    return;
                }

                if (!playBoxGame) {
                    if ("y".equalsIgnoreCase(readString)) {
                        playBoxGame = bonusGame.play(1);
                    }
                }

                if (playBoxGame) {
                    LOGGER.info("Choose a box <1, 2, 3, 4, 5>");
                    String boxNumberStr = scanner.nextLine();
                    int box = Integer.parseInt(boxNumberStr);
                    playBoxGame = bonusGame.play(box);
                    if (playBoxGame) {
                        LOGGER.info("You Win");
                    }
                } else {
                    LOGGER.info("You lost. Would you like to continue? (y/n)");
                    readString = scanner.nextLine();
                }
            }
        }
    }
}
