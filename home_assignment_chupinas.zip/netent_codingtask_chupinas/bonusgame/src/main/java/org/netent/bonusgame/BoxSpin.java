package org.netent.bonusgame;

import org.netent.game.Spin;

import java.util.Random;

public class BoxSpin implements Spin<Box[]> {

    @Override
    public Box[] spin() {
        Box[] boxes = new Box[]{
                new Box(true),
                new Box(true),
                new Box(true),
                new Box(true),
                new Box(false)
        };
        Random random = new Random();
        random.nextInt();
        for (int i = 0; i < boxes.length; i++) {
            int rundomIndex = random.nextInt(boxes.length - 1);
            Box tmp = boxes[i];
            boxes[i] = boxes[rundomIndex];
            boxes[rundomIndex] = tmp;
        }
        return boxes;
    }
}
