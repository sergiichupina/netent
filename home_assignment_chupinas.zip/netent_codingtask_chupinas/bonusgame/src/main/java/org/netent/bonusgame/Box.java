package org.netent.bonusgame;

public class Box {
    private boolean opened;

    private boolean isWin;

    public Box(boolean isWin) {
        this.isWin = isWin;
    }

    public boolean isWin() {
        return isWin;
    }

    public void setOpened(boolean opened) {
        this.opened = opened;
    }

    public boolean isOpened() {
        return opened;
    }

    @Override
    public String toString() {
        return "Box{isWin=" + isWin + '}';
    }
}
