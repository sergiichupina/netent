package org.netent.bonusgame;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.netent.game.Spin;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

class BoxSpinTest {

    @Test
    @DisplayName("Return negative results")
    void shuffleBoxes() {
        Spin<Box[]> boxSpin = new BoxSpin();
        Box[] shuffleBoxes1 = boxSpin.spin();
        Box[] shuffleBoxes2 = boxSpin.spin();
        assumeTrue(findEndBox(shuffleBoxes1) != findEndBox(shuffleBoxes2));
    }

    private int findEndBox(Box[] boxes) {
        int i = 0;
        while (true) {
            if (!boxes[i].isWin()) return i;
            i++;
        }
    }
}