package org.netent.bonusgame;

import org.junit.jupiter.api.Test;
import org.netent.game.Game;
import org.netent.game.Rtp;

import static org.junit.jupiter.api.Assumptions.assumeTrue;

class StatisticBoxPickingGameTest {

    @Test
    void calculate() {
        Game game = new BoxPickingGame(new BoxSpin());
        StatisticBoxPickingGame statistic = new StatisticBoxPickingGame(game);
        Rtp calculateRtp = statistic.calculate(1000000);
        assumeTrue(calculateRtp.calculate() > 60);
    }
}