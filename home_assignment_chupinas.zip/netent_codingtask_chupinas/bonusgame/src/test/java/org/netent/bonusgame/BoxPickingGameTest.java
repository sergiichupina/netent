package org.netent.bonusgame;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.netent.game.Game;
import org.netent.game.Spin;

import static org.junit.jupiter.api.Assertions.*;

class BoxPickingGameTest {

    private Spin boxSpin = Mockito.mock(BoxSpin.class);

    private Box[] expectedResult = new Box[]{
            new Box(true),
            new Box(true),
            new Box(true),
            new Box(true),
            new Box(false)
    };

    @Test
    void playBoxPickingGame() {
        Game<Integer, Boolean> game = new BoxPickingGame(new BoxSpin());
        Boolean result = game.play(1);
        assertNotEquals(expectedResult, result);
    }

    @Test
    void openBoxes() {
        Mockito.when(boxSpin.spin()).thenReturn(expectedResult);
        Game<Integer, Boolean> game = new BoxPickingGame(boxSpin);

        assertAll("Results positive and negative",
                () -> assertTrue(game.play(1)),
                () -> assertFalse(game.play(5))
        );
    }

    @Test
    void openWinBoxGetReward() {
        Mockito.when(boxSpin.spin()).thenReturn(expectedResult);
        Game<Integer, Boolean> game = new BoxPickingGame(boxSpin);

        game.play(1);

        assertAll("Win 5 coins",
                () -> assertEquals(5, game.getTotalWin()),
                () -> assertEquals(0, game.getTotalLoss())
        );
    }

    @Test
    void openEndBoxGetNothing() {
        Mockito.when(boxSpin.spin()).thenReturn(expectedResult);
        Game<Integer, Boolean> game = new BoxPickingGame(boxSpin);

        game.play(5);

        assertAll("Win nothing",
                () -> assertEquals(0, game.getTotalWin()),
                () -> assertEquals(0, game.getTotalLoss())
        );
    }
}