package org.netent.bonusgame;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.netent.game.BonusSpin;
import org.netent.game.Game;
import org.netent.game.Result;
import org.netent.game.Spin;

import static org.junit.jupiter.api.Assertions.*;

public class BonusGameTest {

    @Test
    @DisplayName("Lose a bet")
    public void lostBet() {
        Spin bonusSpin = Mockito.mock(BonusSpin.class);
        Game<Integer, Boolean> bonusGame = new BonusGame(bonusSpin);

        Mockito.when(bonusSpin.spin()).thenReturn(null);

        Boolean result = bonusGame.play(0);

        assertAll("Results positive and negative",
                () -> assertEquals(0, bonusGame.getTotalWin()),
                () -> assertEquals(10, bonusGame.getTotalLoss()),
                () -> assertFalse(result)
        );
    }

    @Test
    @DisplayName("Win bonus game")
    public void winBonusGame() {
        Spin bonusSpin = Mockito.mock(BonusSpin.class);
        Game<Integer, Boolean> bonusGame = new BonusGame(bonusSpin);

        Mockito.when(bonusSpin.spin()).thenReturn(Result.BONUS);

        Boolean result = bonusGame.play(0);

        assertAll("Results positive and negative",
                () -> assertEquals(0, bonusGame.getTotalWin()),
                () -> assertEquals(10, bonusGame.getTotalLoss()),
                () -> assertTrue(result)
        );
    }

}
