package org.netent.slotgame;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.netent.game.*;

import java.util.Arrays;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class SlotMachineTest {

    private Spin betSpin = Mockito.mock(BetSpin.class);

    private Spin bonusSpin = Mockito.mock(BonusSpin.class);

    private Spin spin = new SlotMachineSpin(Arrays.asList(betSpin, bonusSpin));

    @Test
    void winNoFreeRound() {
        Mockito.when(betSpin.spin()).thenReturn(Result.WIN);
        Game<Boolean, Set<Result>> slotMachine = new SlotMachine(spin);

        slotMachine.play(false);

        assertAll("Results",
                () -> assertEquals(20, slotMachine.getTotalWin()),
                () -> assertEquals(10, slotMachine.getTotalLoss())
        );
    }

    @Test
    void winYesFreeRound() {
        Mockito.when(betSpin.spin()).thenReturn(Result.WIN);
        Game<Boolean, Set<Result>> slotMachine = new SlotMachine(spin);

        slotMachine.play(true);
        assertAll("Results",
                () -> assertEquals(20, slotMachine.getTotalWin()),
                () -> assertEquals(0, slotMachine.getTotalLoss())
        );
    }

    @Test
    void winFreeRound() {
        Mockito.when(bonusSpin.spin()).thenReturn(Result.BONUS);
        Game<Boolean, Set<Result>> slotMachine = new SlotMachine(spin);

        slotMachine.play(false);

        assertAll("Results",
                () -> assertEquals(0, slotMachine.getTotalWin()),
                () -> assertEquals(10, slotMachine.getTotalLoss())
        );
    }

    @Test
    void lostEverything() {
        Mockito.when(betSpin.spin()).thenReturn(Result.LOST);
        Mockito.when(bonusSpin.spin()).thenReturn(null);

        Game<Boolean, Set<Result>> slotMachine = new SlotMachine(spin);

        slotMachine.play(false);

        assertAll("Results",
                () -> assertEquals(0, slotMachine.getTotalWin()),
                () -> assertEquals(10, slotMachine.getTotalLoss())
        );
    }
}