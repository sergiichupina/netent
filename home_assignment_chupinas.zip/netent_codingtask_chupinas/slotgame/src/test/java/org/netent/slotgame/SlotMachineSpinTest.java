package org.netent.slotgame;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.netent.game.BetSpin;
import org.netent.game.BonusSpin;
import org.netent.game.Result;
import org.netent.game.Spin;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class SlotMachineSpinTest {

    @Test
    @DisplayName("Return two results")
    void alwaysReturnTwoResults() {
        Spin<Set<Result>>  slotMachineSpin = new SlotMachineSpin(Arrays.asList(new BetSpin(), new BonusSpin()));
        Set<Result> results = slotMachineSpin.spin();
        assertEquals(2, results.size());
    }

    @Test
    @DisplayName("Return positive results")
    public void returnPositives() {
        Spin generatorMoney = Mockito.mock(BetSpin.class);
        Spin generatorFreeGame = Mockito.mock(BonusSpin.class);
        Mockito.when(generatorMoney.spin()).thenReturn(Result.WIN);
        Mockito.when(generatorFreeGame.spin()).thenReturn(Result.BONUS);

        Spin<Set<Result>> slotMachine = new SlotMachineSpin(Arrays.asList(generatorMoney, generatorFreeGame));

        Set<Result> results = slotMachine.spin();
        assertAll("Results",
                () -> assertTrue(results.contains(Result.BONUS)),
                () -> assertTrue(results.contains(Result.WIN))
        );
    }

    @Test
    @DisplayName("Return negative results")
    public void returnNegatives() {
        Spin generatorMoney = Mockito.mock(BetSpin.class);
        Spin generatorFreeGame = Mockito.mock(BonusSpin.class);
        Mockito.when(generatorMoney.spin()).thenReturn(Result.LOST);
        Mockito.when(generatorFreeGame.spin()).thenReturn(null);

        Spin<Set<Result>> slotMachine = new SlotMachineSpin(Arrays.asList(generatorMoney, generatorFreeGame));

        Set<Result> results = slotMachine.spin();
        assertAll("Results",
                () -> assertTrue(results.contains(Result.LOST)),
                () -> assertTrue(results.contains(null))
        );
    }
}