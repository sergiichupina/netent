package org.netent.slotgame;

import org.junit.jupiter.api.Test;
import org.netent.game.*;

import java.util.Arrays;
import java.util.Set;

import static org.junit.jupiter.api.Assumptions.assumeTrue;

class StatisticsSlotMachineTest {

    @Test
    void calculate() {
        Spin spin = new SlotMachineSpin(Arrays.asList(new BetSpin(), new BonusSpin()));
        Game<Boolean, Set<Result>> slotMachine = new SlotMachine(spin);
        Statistics statistic = new StatisticsSlotMachine(slotMachine);
        Rtp calculateRtp = statistic.calculate(10000);
        assumeTrue(calculateRtp.calculate() > 60);
    }
}