package org.netent.slotgame;

import org.netent.game.Result;
import org.netent.game.Spin;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class SlotMachineSpin implements Spin<Set<Result>> {

    private List<Spin<Result>> spinners;

    public SlotMachineSpin(List<Spin<Result>> spinners) {
        this.spinners = spinners;
    }

    public Set<Result> spin() {
        return spinners.stream().map(Spin::spin).collect(Collectors.toSet());
    }
}
