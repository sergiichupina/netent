package org.netent.slotgame;

import org.netent.game.Game;
import org.netent.game.Result;
import org.netent.game.Rtp;
import org.netent.game.Statistics;

import java.util.Set;
import java.util.logging.Logger;

import static org.netent.game.ApplicationConfig.INSTANCE;

public class StatisticsSlotMachine implements Statistics {

    private static Logger LOGGER = INSTANCE.getLogger(StatisticsSlotMachine.class.getName());

    private Game<Boolean, Set<Result>>  game;

    public StatisticsSlotMachine(Game game) {
        this.game = game;
    }

    @Override
    public Rtp calculate(int trials) {

        boolean freeGame = false;
        for (int i = 1; i <= trials; i++) {
            Set<Result> results = game.play(freeGame);
            freeGame = results.contains(Result.BONUS);
        }
        Rtp rtp = new Rtp(game.getTotalWin(), game.getTotalLoss());

        LOGGER.info(game.toString());
        LOGGER.info(rtp.toString());
        return rtp;
    }
}
