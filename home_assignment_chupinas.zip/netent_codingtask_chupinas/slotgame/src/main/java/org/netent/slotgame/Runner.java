package org.netent.slotgame;

import org.netent.game.*;

import java.util.Arrays;
import java.util.Scanner;
import java.util.Set;
import java.util.logging.Logger;

import static org.netent.game.ApplicationConfig.INSTANCE;
import static org.netent.game.ApplicationConfig.STATISTICS_AGRGUMENT;
import static org.netent.game.Result.BONUS;
import static org.netent.game.Result.WIN;

public class Runner {

    private static Logger LOGGER = INSTANCE.getLogger(Runner.class.getName());

    public static void main(String[] args) {

        Spin spin = new SlotMachineSpin(Arrays.asList(new BetSpin(), new BonusSpin()));
        Game<Boolean, Set<Result>> slotMachine = new SlotMachine(spin);

        Arrays.stream(args).forEach(s -> {
            if(STATISTICS_AGRGUMENT.equals(s)){
                Statistics statistic = new StatisticsSlotMachine(slotMachine);
                statistic.calculate(1000000);
                System.exit(0);
            }
        });

        try (Scanner scanner = new Scanner(System.in)) {
            LOGGER.info("Press 'Enter' to make a bet or press any key to quit");
            String readString = scanner.nextLine();
            boolean freeRound = false;
            Set<Result> results;
            while (true) {
                if (freeRound || readString.isEmpty()) {
                    results = slotMachine.play(freeRound);

                    if(results.contains(WIN)){
                        LOGGER.info("You WIN");
                    }

                    freeRound = results.contains(Result.BONUS);

                    if(freeRound){
                        LOGGER.info("You have FREE round");
                    }

                    if(!results.contains(WIN) && !results.contains(BONUS)){
                        LOGGER.info("You lost. Try again");
                    }

                    if (!freeRound) {
                        LOGGER.info("Press 'ENTER' to continue");
                        readString = scanner.nextLine();
                    }
                }

                if (!readString.isEmpty()) {
                    LOGGER.info(slotMachine.toString());
                    LOGGER.info("Thank you and good bye");
                    return;
                }
            }
        }
    }
}
