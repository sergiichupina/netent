package org.netent.slotgame;

import org.netent.game.Game;
import org.netent.game.Result;
import org.netent.game.Spin;

import java.util.Set;

import static org.netent.game.ApplicationConfig.INSTANCE;
import static org.netent.game.Result.BONUS;
import static org.netent.game.Result.WIN;

public class SlotMachine implements Game<Boolean, Set<Result>> {

    private double totalWin;

    private double totalLost;

    private double stake;

    private int bets;

    private int bonusGames;

    private int wins;

    private int reword;

    private Spin<Set<Result>> spin;

    public SlotMachine(Spin spin) {
        this.reword = Integer.valueOf(INSTANCE.getProperty("slotgame.reword"));
        this.stake = Double.valueOf(INSTANCE.getProperty("slotgame.stake"));
        this.spin = spin;
    }

    public Set<Result> play(Boolean freeRound) {
        bets++;
        totalLost += freeRound ? 0 : stake;

        Set<Result> results = spin.spin();

        if (results.contains(WIN)) {
            wins++;
            totalWin += reword;
        }

        if (results.contains(BONUS)) {
            bonusGames++;
        }
        return results;
    }

    public double getTotalWin() {
        return totalWin;
    }

    public double getTotalLoss() {
        return totalLost;
    }

    public int getBets() {
        return bets;
    }

    public int getWins() {
        return wins;
    }

    @Override
    public String toString() {
        return "Result:" +
                " win credits = " + getTotalWin() + " coins" +
                ", lose credits = " + getTotalLoss() + " coins" +
                ", total games = " + getBets() +
                ", bonus games = " + bonusGames +
                ", wins = " + getWins() + " games" +
                ", losses = " + (getBets() - getWins()) + " games";
    }
}
