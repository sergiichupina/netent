##Usage
General instructions on how to use the task

###Build
mvn clean install

###SlotGame:

Start the game

java -jar slotgame-1.0.0-SNAPSHOT-jar-with-dependencies.jar

Run the statistics 

java -jar slotgame-1.0.0-SNAPSHOT-jar-with-dependencies.jar -rtp


###BonusGame:
java -jar bonusgame-1.0.0-SNAPSHOT-jar-with-dependencies.jar

Run the statistics 

java -jar bonusgame-1.0.0-SNAPSHOT-jar-with-dependencies.jar -rtp